package com.example.project_4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.CountDownTimer;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class activity_student_quiz extends AppCompatActivity {

    private Button next;
    private TextView subject;
    private TextView topic;
    private TextView timerView;
    private TextView question;
    private RadioGroup radioGroup;
    private RadioButton radioA;
    private RadioButton radioB;
    private RadioButton radioC;
    private RadioButton radioD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_quiz);

        next = findViewById(R.id.btnNextId);
        subject = findViewById(R.id.subjectQuizId);
        topic = findViewById(R.id.topicQuizId);
        timerView = findViewById(R.id.timerQuizId);
        question = findViewById(R.id.questionQuizId);
        radioGroup = findViewById(R.id.radioGroup);
        radioA = findViewById(R.id.radioA);
        radioB = findViewById(R.id.radioB);
        radioC = findViewById(R.id.radioC);
        radioD = findViewById(R.id.radioD);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fill
            }
        });
    }
}