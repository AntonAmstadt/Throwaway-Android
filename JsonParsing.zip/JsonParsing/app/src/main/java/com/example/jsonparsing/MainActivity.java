package com.example.jsonparsing;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private ListView lv;
    private ProgressDialog pDialog;

    private static String url = "https://api.androidhive.info/contacts/";
    ArrayList<HashMap<String, String>> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactList = new ArrayList<>();

        lv = findViewById(R.id.list);

        new GetContacts().execute();
    }




    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute(){
            super.onPreExecute();

            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait ...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
                HttpHandler sh = new HttpHandler();

                String jsonStr = sh.makeServiceCall(url);

                if (jsonStr != null)
                {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);
                         
                        // Calling Json Array
                        JSONArray contacts = jsonObj.getJSONArray("contacts");

                        for (int i = 0; i < contacts.length(); i++)
                        {
                            JSONObject d = contacts.getJSONObject(i);

                            String id = d.getString("id");
                            String name = d.getString("name");
                            String email = d.getString("email");

                            JSONObject phone = d.getJSONObject("phone");
                            String mobile = phone.getString("mobile");

                            HashMap<String, String> contact = new HashMap<>();

                            contact.put("id", id);
                            contact.put("name", name);
                            contact.put("email", email);
                            contact.put("mobile", mobile);

                            contactList.add(contact);

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            return null;
        }

       @Override
       protected void onPostExecute(Void result){
            super.onPostExecute(result);

            if (pDialog.isShowing())
            {
                pDialog.dismiss();
            }

            // We nee to bind data to the listview

           ListAdapter adapter = new SimpleAdapter(MainActivity.this, contactList,
                   R.layout.list_item, new String[] {"name", "email", "mobile"},
                   new int[]{R.id.name, R.id.email, R.id.mobile});


            lv.setAdapter(adapter);
       }

    }
    
    
    
    
}