package com.example.lab3;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private Button m_btnLogin;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_btnLogin = findViewById(R.id.btnLogin);
        username = findViewById(R.id.txtUsername);
        password = findViewById(R.id.txtPassword);
        context = getApplicationContext();


        m_btnLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(context,"Trying to login", Toast.LENGTH_SHORT).show();

            Intent login = new Intent(context, Dashboard.class);

            String user = username.getText().toString();
            String pass = password.getText().toString();
            if(user.compareTo("anton") == 0 && pass.compareTo("123") == 0) {
                startActivity(login);
            }
        }
    });
    }
}