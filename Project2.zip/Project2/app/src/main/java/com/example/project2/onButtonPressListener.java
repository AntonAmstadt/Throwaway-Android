package com.example.project2;

public interface onButtonPressListener {
    void onButtonPressed(int pictureNumber);
    void onCheckBoxPressed(Boolean isChecked);
}
