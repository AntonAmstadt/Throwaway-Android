package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements onButtonPressListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onButtonPressed(int pictureNumber){
        Fragment1 frag = (Fragment1)getSupportFragmentManager()
                .findFragmentById(R.id.fragmentContainerView);
        if(frag != null){
            frag.updatePicture(pictureNumber);
        }
    }

    @Override
    public void onCheckBoxPressed(Boolean isChecked){
        Fragment1 frag = (Fragment1)getSupportFragmentManager()
                .findFragmentById(R.id.fragmentContainerView);
        if (frag != null) {
            frag.slideShow(isChecked);
        }
    }
}