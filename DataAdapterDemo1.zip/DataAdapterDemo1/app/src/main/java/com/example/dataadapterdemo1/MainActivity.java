package com.example.dataadapterdemo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView lvList;

    String animalList[] = {"Lion", "Tiger", "Monkey", "Elephant", "Dog", "Cat", "Camel"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvList = findViewById(R.id.simpleListView);
        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(),R.layout.activity_list_view,
                R.id.textView, animalList);
        lvList.setAdapter(arrayAdapter);

    }
}