package com.example.buttondemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnLogin;
    private Button btnCancel;
    private TextView txtCV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // now have access to all controls in this layout

        btnLogin = findViewById(R.id.btnLog);
        btnCancel = findViewById(R.id.btnCancel);
        txtCV = findViewById(R.id.txtCoolView);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            int i = 0;
            @Override
            public void onClick(View v) {
                if(i == 0) {
                    txtCV.setText("Cool Code");
                    i = 1;
                }
                else if(i == 1) {
                    txtCV.setText("Super Cool Code");
                    i = 0;
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                //whatever you want the button to do goes here
                txtCV.setText("Cancel");
            }
        });

    }
}