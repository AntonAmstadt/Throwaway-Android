package com.example.frag1;

public interface onButtonPressListner {
    void onButtonPressed(String msg);
}
