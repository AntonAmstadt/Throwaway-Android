package com.example.project_2;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Animals#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Animals extends Fragment {

    ImageView animalView;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private int mParam2;

    public Animals() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Animals.
     */
    // TODO: Rename and change types and number of parameters
    public static Animals newInstance(String param1, int param2) {
        Animals fragment = new Animals();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, "Hello World");
        args.putInt(ARG_PARAM2, param2);
        //args.getInt(param1, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getInt(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = (View) inflater.inflate(R.layout.fragment_animals, container, false);
        animalView = root.findViewById(R.id.animal_icon);
        animalView.setImageResource(mParam2);
        System.out.println("THIS IS drawable: " + R.drawable.animal13);
        System.out.println("THIS IS mPARAM1: " + mParam1);
        System.out.println("THIS IS mPARAM2: " + mParam2);
        return root;
    }
}