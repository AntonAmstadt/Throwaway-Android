package com.example.project_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    int animals_List[] = {R.drawable.animal13, R.drawable.animal14, R.drawable.animal15,
            R.drawable.animal16, R.drawable.animal17, R.drawable.animal18};

    private Button forward;
    private Button backward;
    private CheckBox slideshow;
    private Controller controller_Frag;
    private Animals animals_Frag;
    private int current = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       animals_Frag = Animals.newInstance("Data", animals_List[current]);
       FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
       transaction.replace(R.id.animal_Fragment, animals_Frag);
       transaction.addToBackStack(null);
       transaction.commit();

        forward = findViewById(R.id.forward);
        backward = findViewById(R.id.backward);
        slideshow = findViewById(R.id.slideshow);

        slideshow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (buttonView.isChecked()){
                    Toast.makeText(getApplicationContext(), "True", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "False", Toast.LENGTH_SHORT).show();
                }
            }
        });

        forward.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            if(current == animals_List.length - 1){
                Toast.makeText(getApplicationContext(), "End", Toast.LENGTH_SHORT).show();
            }
            else {
                current++;
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                animals_Frag = Animals.newInstance("Data", animals_List[current]);
                transaction.replace(R.id.animal_Fragment, animals_Frag);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        }

        });

        backward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (current == 0) {
                    Toast.makeText(getApplicationContext(), "Start", Toast.LENGTH_SHORT).show();
                } else {
                    current--;
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    animals_Frag = Animals.newInstance("Data", animals_List[current]);
                    transaction.replace(R.id.animal_Fragment, animals_Frag);
                    transaction.addToBackStack(null);
                    transaction.commit();
                }
            }
        });

    }
}