package com.example.animationdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showFragment1();

    }

    private void showFragment1(){
        Fragment frag1 = new Fragment1();

        getSupportFragmentManager().beginTransaction().replace(R.id.container, frag1).commit();
    }

}