package com.example.fragmentdemo2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btnSend;
    private EditText edtMessage;
    private Fragment1 mFrag1;
    private Fragment2 mFrag2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = findViewById(R.id.btnSend);
        edtMessage = findViewById(R.id.edtMessage);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFrag1 = Fragment1.newInstance("Data", "Fragment 1");
                mFrag2 = Fragment2.newInstance("Data",edtMessage.getText().toString());

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragmentContainerView, mFrag2);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });
    }
}