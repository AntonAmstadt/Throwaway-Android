package com.example.recylcerviewdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<MyViewHolder> {

    ArrayList<String> animalNames;
    ArrayList<Integer> animalImages;
    Context context;


    public CustomAdapter(Context context, ArrayList<String> animalNames, ArrayList<Integer> animalImages){
        this.animalNames = animalNames;
        this.animalImages = animalImages;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rowlayout,
                parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position){
        holder.tvAnimalName.setText(animalNames.get(position));
        holder.ivAnimalImage.setImageResource(animalImages.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, animalNames.get(position), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount(){
        return animalNames.size();
    }
}
