package com.example.recylcerviewdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> animalNames = new ArrayList<>(Arrays.asList("animal 13", "animal 14",
            "animal 15", "animal 16", "animal 17", "animal 18"));

    ArrayList<Integer> animalImages =  new ArrayList<>(Arrays.asList(R.drawable.animal13,
            R.drawable.animal14, R.drawable.animal15,
            R.drawable.animal16, R.drawable.animal17,
            R.drawable.animal18));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.rvAnimals);

        LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
        rv.setLayoutManager(llm);
        CustomAdapter ca = new CustomAdapter(getApplicationContext(), animalNames, animalImages);
        rv.setAdapter(ca);
    }
}