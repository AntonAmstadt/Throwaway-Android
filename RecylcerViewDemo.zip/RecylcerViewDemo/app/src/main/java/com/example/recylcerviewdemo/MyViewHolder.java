package com.example.recylcerviewdemo;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder{

    TextView tvAnimalName;
    ImageView ivAnimalImage;

    public MyViewHolder(View itemView) {
        super(itemView);
        tvAnimalName = itemView.findViewById(R.id.name);
        ivAnimalImage = itemView.findViewById(R.id.image);
    }

}
