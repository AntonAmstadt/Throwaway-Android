package com.example.fragmentdemo;

public interface onButtonPressListener {

    void onButtonPressed(String msg);

}
