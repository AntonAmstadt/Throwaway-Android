package com.example.june2lectureexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private CheckBox chkBox;
    private RadioGroup grpGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkBox = findViewById(R.id.checkBox);
        grpGender = findViewById(R.id.rgrpGender);

        chkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    Toast.makeText(getApplicationContext(), "I'm checked",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        grpGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rb = group.findViewById(checkedId);

                if (rb != null){
                    Toast.makeText(getApplicationContext(), rb.getText(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}